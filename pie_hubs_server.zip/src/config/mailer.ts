export default {
  name: "gmail",
  host: "smtp.gmail.com",
  port: 465,
  auth: {
    user: "genie@truetechsolutions.in",
    pass: "Screenit@12345",
  },
};
